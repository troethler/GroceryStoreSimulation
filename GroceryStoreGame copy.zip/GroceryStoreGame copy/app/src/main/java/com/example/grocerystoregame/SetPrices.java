package com.example.grocerystoregame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class SetPrices extends AppCompatActivity {
private double tpPrice = 6.00;
private double hsPrice = 3.00;
private double cheesePrice = 1.00;
private double milkPrice = 1.00;
private double beefPrice = 10.00;
private double poultryPrice = 7.00;
private double chipsPrice = 2.50;
private double candyPrice = 3.50;
private double vegPrice = 3.00;
private double fruitPrice = 1.50;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_prices);

        ImageButton minusTpPrice = findViewById(R.id.tpminus);
        ImageButton plusTpPrice = findViewById(R.id.tpplus);
        TextView tpPriceText = findViewById(R.id.tpprice);

        minusTpPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tpPrice = tpPrice - 0.15;
                tpPriceText.setText("$" + String.format("%.2f", tpPrice));
            }
        });

        plusTpPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tpPrice = tpPrice + 0.15;
                tpPriceText.setText("$" + String.format("%.2f", tpPrice));
            }
        });

        ImageButton minusHsPrice = findViewById(R.id.hsminus);
        ImageButton plusHsPrice = findViewById(R.id.hsplus);
        TextView hsPriceText = findViewById(R.id.hsprice);

        minusHsPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                hsPrice = hsPrice - 0.15;
                hsPriceText.setText("$" + String.format("%.2f", hsPrice));
            }
        });

        plusHsPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                hsPrice = hsPrice + 0.15;
                hsPriceText.setText("$" + String.format("%.2f", hsPrice));
            }
        });

        ImageButton minusCheesePrice = findViewById(R.id.cheeseminus);
        ImageButton plusCheesePrice = findViewById(R.id.cheeseplus);
        TextView cheesePriceText = findViewById(R.id.cheeseprice);

        minusCheesePrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cheesePrice = cheesePrice - 0.15;
                cheesePriceText.setText("$" + String.format("%.2f", cheesePrice));
            }
        });

        plusCheesePrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cheesePrice = cheesePrice + 0.15;
                cheesePriceText.setText("$" + String.format("%.2f", cheesePrice));
            }
        });

        ImageButton minusMilkPrice = findViewById(R.id.milkminus);
        ImageButton plusMilkPrice = findViewById(R.id.milkplus);
        TextView milkPriceText = findViewById(R.id.milkprice);

        minusMilkPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                milkPrice = milkPrice - 0.15;
                milkPriceText.setText("$" + String.format("%.2f", milkPrice));
            }
        });

        plusMilkPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                milkPrice = milkPrice + 0.15;
                milkPriceText.setText("$" + String.format("%.2f", milkPrice));
            }
        });

        ImageButton minusBeefPrice = findViewById(R.id.beefminus);
        ImageButton plusBeefPrice = findViewById(R.id.beefplus);
        TextView beefPriceText = findViewById(R.id.beefprice);

        minusBeefPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                beefPrice = beefPrice - 0.15;
                beefPriceText.setText("$" + String.format("%.2f", beefPrice));
            }
        });

        plusBeefPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                beefPrice = beefPrice + 0.15;
                beefPriceText.setText("$" + String.format("%.2f", beefPrice));
            }
        });

        ImageButton minusPoultryPrice = findViewById(R.id.poultryminus);
        ImageButton plusPoultryPrice = findViewById(R.id.poultryplus);
        TextView poultryPriceText = findViewById(R.id.poultryprice);

        minusPoultryPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                poultryPrice = poultryPrice - 0.15;
                poultryPriceText.setText("$" + String.format("%.2f", poultryPrice));
            }
        });

        plusPoultryPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                poultryPrice = poultryPrice + 0.15;
                poultryPriceText.setText("$" + String.format("%.2f", poultryPrice));
            }
        });

        ImageButton minusChipsPrice = findViewById(R.id.chipsminus);
        ImageButton plusChipsPrice = findViewById(R.id.chipsplus);
        TextView chipsPriceText = findViewById(R.id.chipsprice);

        minusChipsPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                chipsPrice = chipsPrice - 0.15;
                chipsPriceText.setText("$" + String.format("%.2f", chipsPrice));
            }
        });

        plusChipsPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                chipsPrice = chipsPrice + 0.15;
                chipsPriceText.setText("$" + String.format("%.2f", chipsPrice));
            }
        });

        ImageButton minusCandyPrice = findViewById(R.id.candyminus);
        ImageButton plusCandyPrice = findViewById(R.id.candyplus);
        TextView candyPriceText = findViewById(R.id.candyprice);

        minusCandyPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                candyPrice = candyPrice - 0.15;
                candyPriceText.setText("$" + String.format("%.2f", candyPrice));
            }
        });

        plusCandyPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                candyPrice = candyPrice + 0.15;
                candyPriceText.setText("$" + String.format("%.2f", candyPrice));
            }
        });

        ImageButton minusVegPrice = findViewById(R.id.vegminus);
        ImageButton plusVegPrice = findViewById(R.id.vegplus);
        TextView vegPriceText = findViewById(R.id.vegprice);

        minusVegPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                vegPrice = vegPrice - 0.15;
                vegPriceText.setText("$" + String.format("%.2f", vegPrice));
            }
        });

        plusVegPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                vegPrice = vegPrice + 0.15;
                vegPriceText.setText("$" + String.format("%.2f", vegPrice));
            }
        });

        ImageButton minusFruitPrice = findViewById(R.id.fruitminus);
        ImageButton plusFruitPrice = findViewById(R.id.fruitplus);
        TextView fruitPriceText = findViewById(R.id.fruitprice);

        minusFruitPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fruitPrice = fruitPrice - 0.15;
                fruitPriceText.setText("$" + String.format("%.2f", fruitPrice));
            }
        });

        plusFruitPrice.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fruitPrice = fruitPrice + 0.15;
                fruitPriceText.setText("$" + String.format("%.2f", fruitPrice));
            }
        });
    }


    public void goToSetStoreHours(View view) {
        Intent intent = new Intent(SetPrices.this, StoreHours.class);
        startActivity(intent);
    }
}