package com.example.grocerystoregame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class BuyItems extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_items);
    }

    public void goToHealthyFoodBundles(View view) {
        Intent intent = new Intent(BuyItems.this, HealthyFood.class);
        startActivity(intent);
    }
    public void goToCleaningProductBundles(View view) {
        Intent intent = new Intent(BuyItems.this, CleaningProduct.class);
        startActivity(intent);
    }
    public void goToDairyProductBundles(View view) {
        Intent intent = new Intent(BuyItems.this, DairyProduct.class);
        startActivity(intent);
    }
    public void goToMeatProductBundles(View view) {
        Intent intent = new Intent(BuyItems.this, MeatProduct.class);
        startActivity(intent);
    }
    public void goToSnackFoodBundles(View view) {
        Intent intent = new Intent(BuyItems.this, SnackFood.class);
        startActivity(intent);
    }
    public void goToSetPrices(View view) {
        Intent intent = new Intent(BuyItems.this, SetPrices.class);
        startActivity(intent);
    }
}
