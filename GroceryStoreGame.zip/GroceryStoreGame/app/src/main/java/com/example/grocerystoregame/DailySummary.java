package com.example.grocerystoregame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DailySummary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_summary);
    }

    public void goToDailyInsights(View view) {
        Intent intent = new Intent(DailySummary.this, DailyInsights.class);
        startActivity(intent);
    }
    public void goToWeeklySummary(View view) {
        Intent intent = new Intent(DailySummary.this, WeeklySummary.class);
        startActivity(intent);
    }
}