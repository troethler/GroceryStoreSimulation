package com.example.grocerystoregame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SetPrices extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_prices);
    }

    public void goToSetStoreHours(View view) {
        Intent intent = new Intent(SetPrices.this, StoreHours.class);
        startActivity(intent);
    }
}